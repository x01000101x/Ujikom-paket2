<?php

namespace Encore\Admin\Layout;

interface Buildable
{
    public function build();
}
