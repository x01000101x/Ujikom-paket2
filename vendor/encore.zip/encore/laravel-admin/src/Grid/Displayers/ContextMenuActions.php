<?php

namespace Encore\Admin\Grid\Displayers;

class ContextMenuActions extends DropdownActions
{
    protected $view = 'admin::grid.actions.contextmenu';
}
