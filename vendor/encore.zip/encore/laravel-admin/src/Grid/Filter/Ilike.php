<?php

namespace Encore\Admin\Grid\Filter;

class Ilike extends Like
{
    protected $operator = 'ilike';
}
