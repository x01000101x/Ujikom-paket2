<?php

namespace Encore\Admin\Form\Field;

class TimeRange extends DateRange
{
    protected $format = 'HH:mm:ss';
}
